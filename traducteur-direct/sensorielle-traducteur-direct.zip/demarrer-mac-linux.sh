#!/bin/bash
cd "$(dirname "$0")"
echo "Démarrage du traducteur LSQ (hors ligne)..."
(sleep 1 && (command -v open >/dev/null && open http://localhost:8878/ || xdg-open http://localhost:8878/)) &

if command -v python3 >/dev/null; then
  python3 -m http.server 8878
elif command -v python >/dev/null; then
  python -m http.server 8878
elif command -v node >/dev/null; then
  node -e "const h=require('http'),fs=require('fs'),path=require('path');const types={'.html':'text/html','.js':'text/javascript','.json':'application/json','.bin':'application/octet-stream','.png':'image/png'};h.createServer((req,res)=>{let p=decodeURIComponent(req.url.split('?')[0]);if(p==='/')p='/index.html';const full=path.join(__dirname,p);fs.readFile(full,(err,data)=>{if(err){res.writeHead(404);res.end('404');return;}res.writeHead(200,{'Content-Type':types[path.extname(full)]||'application/octet-stream'});res.end(data);});}).listen(8878,()=>console.log('Serveur local pret sur http://localhost:8878/'));"
else
  echo "Aucun programme trouvé (ni Python, ni Node.js). Installe l'un des deux puis réessaie."
  exit 1
fi
