@echo off
cd /d "%~dp0"
echo Demarrage du traducteur LSQ (hors ligne)...
echo Ferme cette fenetre noire seulement apres avoir fini de l'utiliser.
echo.

where node >nul 2>nul
if %errorlevel%==0 (
    echo Lancement avec Node.js...
    start "" http://localhost:8878/
    node -e "const h=require('http'),fs=require('fs'),path=require('path');const types={'.html':'text/html','.js':'text/javascript','.json':'application/json','.bin':'application/octet-stream','.png':'image/png'};h.createServer((req,res)=>{let p=decodeURIComponent(req.url.split('?')[0]);if(p==='/')p='/index.html';const full=path.join(__dirname,p);fs.readFile(full,(err,data)=>{if(err){res.writeHead(404);res.end('404');return;}res.writeHead(200,{'Content-Type':types[path.extname(full)]||'application/octet-stream'});res.end(data);});}).listen(8878,()=>console.log('Serveur local pret sur http://localhost:8878/'));"
    goto :eof
)

where python >nul 2>nul
if %errorlevel%==0 (
    echo Lancement avec Python...
    start "" http://localhost:8878/
    python -m http.server 8878
    goto :eof
)

where py >nul 2>nul
if %errorlevel%==0 (
    echo Lancement avec Python...
    start "" http://localhost:8878/
    py -m http.server 8878
    goto :eof
)

echo.
echo AUCUN programme trouve pour demarrer (ni Node.js, ni Python).
echo Installe l'un des deux (gratuit) puis redemarre ce fichier :
echo   - Node.js : https://nodejs.org
echo   - Python  : https://python.org (coche "Add to PATH" a l'installation)
echo.
pause
